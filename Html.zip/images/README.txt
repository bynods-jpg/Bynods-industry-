PHOTOS KAHAN LAGANI HAIN
Is folder (images) mein apni photos in naamon se daalein. Jitni photos hongi utni website par nazar aayengi,
jahan photo nahi hogi woh hissa khud chhup jayega.
Format: .jpg ya .png ya .webp. Har photo 100-300 KB ke aas paas rakhein (bohat bari photos site slow karti hain).

Factory (About ke saath, max 4):  factory-1.jpg ... factory-4.jpg (abhi 3 laga hai: factory ki bahar se photos)
Our work (sab se neeche, max 12): work-1.jpg ... work-12.jpg (abhi: godam, cutting, pink table, screen printing, embroidery, dispatch)
Jackets (max 60):         jackets-1.jpg ... jackets-15.jpg
Hoodies (max 60):         hoodies-1.jpg ... hoodies-15.jpg
Tracksuits (max 60):      tracksuits-1.jpg ... tracksuits-15.jpg
Shirts (max 60):          shirts-1.jpg ... shirts-15.jpg
Shorts (max 60):          shorts-1.jpg ... shorts-15.jpg
Shorts (max 60):          shorts-1.jpg ... shorts-15.jpg
Clubwear (max 60):        clubwear-1.jpg ... clubwear-15.jpg
Top slider (1 photo har):  slide-brand.jpg, slide-jackets.jpg, slide-hoodies.jpg, slide-tracksuits.jpg,
                           slide-shirts.jpg, slide-clubwear.jpg
Numbers 1 se shuru karein aur beech mein khali number na chhodein.
